(function () {
    var create = document.getElementsByClassName("choice");
    create.addEventListener("click", function () {
        window.location.replace("https://learn.gitam.edu", "_blank");
    }, false);
});